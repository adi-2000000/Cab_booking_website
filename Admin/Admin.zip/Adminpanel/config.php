<?php
/* Database credentials. Assuming you are running MySQL
server with default settings (user 'root' with no password) */

if (!defined('DB_SERVER')) {
    define('DB_SERVER', 'localhost:3306');
}

if (!defined('DB_USERNAME')) {
    define('DB_USERNAME', 'root');
}

if (!defined('DB_PASSWORD')) {
    define('DB_PASSWORD', '');
}

if (!defined('DB_NAME')) {
    define('DB_NAME', 'aimcab');
}

/* Attempt to connect to the MySQL database */
$link = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

// Check the connection
if ($link === false) {
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
?>
